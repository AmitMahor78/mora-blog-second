<?php

// Check if running in local development (XAMPP / Windows) or on a live Linux server
$is_local_machine = (
    strpos(__DIR__, 'xampp') !== false 
    || in_array($_SERVER['HTTP_HOST'] ?? '', ['localhost', '127.0.0.1'])
    || php_sapi_name() === 'cli'
);

if ($is_local_machine) {
    // Local XAMPP Settings
    $host     = "localhost";
    $user     = "root";
    $password = "";
    $database = "mora-blog-second";

    $conn = @mysqli_connect($host, $user, $password, $database);
    if (!$conn) {
        // Fallback to mora_blog if mora-blog-second is not selected
        $database = "mora_blog";
        $conn = @mysqli_connect($host, $user, $password, $database);
    }
} else {
    // Live Server Settings (InfinityFree / cPanel / Cloud)
    // NOTE: If using InfinityFree, copy the 'MySQL Hostname' (e.g. sqlXXX.infinityfree.com) from your panel
    $host     = getenv('DB_HOST') ?: "localhost";
    $user     = getenv('DB_USER') ?: "imyvucxq_mora-blog1";
    $password = getenv('DB_PASS') ?: "j7kTP6sGBMfem46PTpnK";
    $database = getenv('DB_NAME') ?: "imyvucxq_mora-blog1";

    $conn = @mysqli_connect($host, $user, $password, $database);
}

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");

?>