
<?php
require_once __DIR__ . '/includes/maintenance-check.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/mailer.php';

$message = "";
$messageType = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    $profileImagePath = null;

    if ($name === '' || $email === '' || $password === '' || $confirm_password === '') {
        $message = "Please fill all required fields.";
        $messageType = "danger";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please enter a valid email address.";
        $messageType = "danger";

    } elseif ($password !== $confirm_password) {
        $message = "Password and Confirm Password do not match.";
        $messageType = "danger";

    } elseif (strlen($password) < 6) {
        $message = "Password must be at least 6 characters long.";
        $messageType = "danger";

    } else {

        // Validate Profile Image if uploaded
        if (isset($_FILES['profile_image']) && !empty($_FILES['profile_image']['name']) && $_FILES['profile_image']['error'] !== UPLOAD_ERR_NO_FILE) {
            $file = $_FILES['profile_image'];
            if ($file['error'] === UPLOAD_ERR_OK) {
                $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
                $fileExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $fileSize = $file['size'];

                if (!in_array($fileExt, $allowedExtensions)) {
                    $message = "Please upload a valid image file (JPG, JPEG, PNG, WEBP, GIF).";
                    $messageType = "danger";
                } elseif ($fileSize > 5 * 1024 * 1024) {
                    $message = "Profile image must be less than 5MB.";
                    $messageType = "danger";
                } else {
                    $imgInfo = @getimagesize($file['tmp_name']);
                    if ($imgInfo === false) {
                        $message = "The uploaded file is not a valid image.";
                        $messageType = "danger";
                    } else {
                        $uploadDir = __DIR__ . '/uploads/profiles/';
                        if (!is_dir($uploadDir)) {
                            @mkdir($uploadDir, 0755, true);
                        }
                        $newFileName = 'avatar_' . time() . '_' . bin2hex(random_bytes(6)) . '.' . $fileExt;
                        $targetPath = $uploadDir . $newFileName;
                        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                            $profileImagePath = 'uploads/profiles/' . $newFileName;
                        } else {
                            $message = "Failed to save uploaded image. Please try again.";
                            $messageType = "danger";
                        }
                    }
                }
            } else {
                $message = "Error uploading image. Please try again.";
                $messageType = "danger";
            }
        }

        if ($message === "") {

            $checkSql = "SELECT id FROM registered_users WHERE email = ? LIMIT 1";
            $checkStmt = mysqli_prepare($conn, $checkSql);

            if (!$checkStmt) {
                $message = "Database error. Please try again.";
                $messageType = "danger";
            } else {
                mysqli_stmt_bind_param($checkStmt, "s", $email);
                mysqli_stmt_execute($checkStmt);
                mysqli_stmt_store_result($checkStmt);

                $emailExists = mysqli_stmt_num_rows($checkStmt) > 0;
                mysqli_stmt_close($checkStmt);

                if ($emailExists) {
                    $message = "This email is already registered.";
                    $messageType = "danger";
                    if ($profileImagePath && file_exists(__DIR__ . '/' . $profileImagePath)) {
                        @unlink(__DIR__ . '/' . $profileImagePath);
                    }
                } else {

                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    $token = bin2hex(random_bytes(32));
                    $tokenHash = hash('sha256', $token);

                    $insertSql = "
                        INSERT INTO registered_users
                        (
                            name,
                            email,
                            password,
                            profile_image,
                            is_verified,
                            verification_token_hash,
                            verification_expires_at
                        )
                        VALUES (?, ?, ?, ?, 0, ?, DATE_ADD(NOW(), INTERVAL 30 MINUTE))
                    ";

                    $insertStmt = mysqli_prepare($conn, $insertSql);

                    if (!$insertStmt) {
                        $message = "Database error. Please try again.";
                        $messageType = "danger";
                    } else {
                        mysqli_stmt_bind_param(
                            $insertStmt,
                            "sssss",
                            $name,
                            $email,
                            $hashedPassword,
                            $profileImagePath,
                            $tokenHash
                        );

                        if (mysqli_stmt_execute($insertStmt)) {

                            $userId = mysqli_insert_id($conn);
                            mysqli_stmt_close($insertStmt);

                            // Dynamic site base URL handles both localhost and published domains (e.g. InfinityFree)
                            $verificationUrl = getMoraSiteBaseUrl()
                                . "/verify-email.php?token="
                                . urlencode($token);

                            $emailBody = "
                                <h2>Welcome to Mora Blog!</h2>
                                <p>Hello " . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . ",</p>
                                <p>Please click the link below to verify your email address.</p>
                                <p>
                                    <a href='" . htmlspecialchars($verificationUrl, ENT_QUOTES, 'UTF-8') . "'>
                                        Verify My Email
                                    </a>
                                </p>
                                <p>This link expires in 30 minutes.</p>
                                <p>If you did not create this account, you can ignore this email.</p>
                            ";

                            if (sendMoraEmail($email, "Verify Your Mora Blog Account", $emailBody)) {
                                $message = "Registration successful! Please check your email and click the verification link. It expires in 30 minutes.";
                                $messageType = "success";
                            } else {
                                // Do not leave an unusable, unverified account behind.
                                $deleteSql = "
                                    DELETE FROM registered_users
                                    WHERE id = ? AND is_verified = 0
                                ";
                                $deleteStmt = mysqli_prepare($conn, $deleteSql);

                                if ($deleteStmt) {
                                    mysqli_stmt_bind_param($deleteStmt, "i", $userId);
                                    mysqli_stmt_execute($deleteStmt);
                                    mysqli_stmt_close($deleteStmt);
                                }

                                if ($profileImagePath && file_exists(__DIR__ . '/' . $profileImagePath)) {
                                    @unlink(__DIR__ . '/' . $profileImagePath);
                                }

                                $mailErr = getMoraMailerLastError();
                                $message = "We could not send the verification email. " . ($mailErr ? "Mailer error: " . htmlspecialchars($mailErr, ENT_QUOTES, 'UTF-8') : "Please check your email settings and try again.");
                                $messageType = "danger";
                            }

                        } else {
                            mysqli_stmt_close($insertStmt);
                            $message = "Registration failed. Please try again.";
                            $messageType = "danger";
                        }
                    }
                }
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="icon" href="images/favicon.png" type="image/x-icon" />

    <title>Mora Blog | Register</title>

    <link href="css/style.css" rel="stylesheet">
    <link href="css/modern.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>


<!-- Header Top Area -->

<?php include "includes/header.php"; ?>

<header class="main_header_area" id="header">
    <div class="container">
        <div class="header_menu">
            <?php include "includes/navbar.php"; ?>
        </div>
    </div>
</header>


<!-- Pages Header Area -->

<div class="container">

    <div class="pages_heder">

        <h2>Register Page</h2>

        <ol class="breadcrumb">

            <li>
                <a href="index.php">Home</a>
            </li>

            <li>
                <a href="">Pages</a>
            </li>

            <li>
                <a href="register.php" class="active">
                    Register
                </a>
            </li>

        </ol>

    </div>

</div>


<!-- Register Area -->

<section class="login_area">

    <div class="container">

        <div class="login_inner">

            <form
                class="row login_from"
                action="register.php"
                method="POST"
                enctype="multipart/form-data"
            >


                <?php if ($message !== '') { ?>

                    <div class="col-12">

                        <div class="alert alert-<?php echo htmlspecialchars($messageType); ?>">

                            <?php echo htmlspecialchars($message); ?>

                        </div>

                    </div>

                <?php } ?>

                <!-- Compact & Reliable Profile Picture Picker -->
                <div class="form-group col-12">
                    <div class="compact-avatar-picker-wrap">
                        <label for="profile_image_input" class="compact-avatar-label" title="Click to choose profile photo">
                            <img id="avatar_preview" src="" alt="Avatar" class="compact-avatar-img" style="display:none;">
                            <span id="avatar_placeholder" class="compact-avatar-placeholder">
                                <i class="fa fa-user"></i>
                            </span>
                            <span class="compact-camera-badge" title="Upload">
                                <i class="fa fa-camera"></i>
                            </span>
                        </label>
                        <div class="compact-avatar-info">
                            <div style="display:flex; align-items:center; gap:8px;">
                                <label for="profile_image_input" class="compact-choose-btn">
                                    <i class="fa fa-upload"></i> <span id="avatar_btn_text">Choose Photo</span>
                                </label>
                                <button type="button" id="avatar_remove_btn" class="compact-remove-btn" style="display:none;" onclick="removeProfileAvatar(event)">
                                    <i class="fa fa-times"></i> Remove
                                </button>
                            </div>
                            <span class="compact-avatar-hint" id="avatar_hint_text">Profile Picture (Optional &bull; Max 5MB)</span>
                        </div>
                        <input
                            type="file"
                            id="profile_image_input"
                            name="profile_image"
                            accept="image/png, image/jpeg, image/jpg, image/webp, image/gif"
                            class="compact-file-input"
                            onchange="previewProfileAvatar(this)"
                        >
                    </div>
                </div>

                <!-- Name -->

                <div class="form-group col-12">

                    <input
                        type="text"
                        class="form-control"
                        name="name"
                        placeholder="Your Name"
                        value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>"
                        required
                    >

                </div>


                <!-- Email -->

                <div class="form-group col-12">

                    <input
                        type="email"
                        class="form-control"
                        name="email"
                        placeholder="Email Address"
                        value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                        required
                    >

                </div>


                <!-- Password -->

                <div class="form-group col-12">

                    <input
                        type="password"
                        class="form-control"
                        name="password"
                        placeholder="Password"
                        required
                    >

                </div>


                <!-- Confirm Password -->

                <div class="form-group col-12">

                    <input
                        type="password"
                        class="form-control"
                        name="confirm_password"
                        placeholder="Confirm Password"
                        required
                    >

                </div>


                <!-- Register Button -->

                <div class="form-group larg_btn col-12">

                    <button
                        class="defult_btn"
                        type="submit"
                    >
                        Register
                    </button>

                </div>


                <div class="form-group col-sm-6">

                    <a href="#" class="reset_btn">
                        Reset Password
                    </a>

                </div>


                <div class="form-group col-sm-6">

                    <a href="login.php" class="reset_btn">
                        Login
                    </a>

                </div>


                <h4 class="col-12">
                    or login in with
                </h4>


                <div class="form-group col-sm-6">

                    <a href="#" class="google_btn">

                        <img src="images/google.png" alt="">

                        GOOGLE

                    </a>

                </div>


                <div class="form-group col-sm-6">

                    <a href="#" class="google_btn">

                        <i class="fa fa-facebook"></i>

                        Sign Up

                    </a>

                </div>


                <div class="col-12">

                    <div class="custom-control custom-checkbox">

                        <input
                            type="checkbox"
                            class="custom-control-input"
                            id="check1"
                            required
                        >

                        <label
                            class="custom-control-label"
                            for="check1"
                        >
                            I agree to the mora.com
                            <a href="#">
                                Terms of Service
                            </a>
                        </label>

                    </div>

                </div>


            </form>

        </div>

    </div>

</section>


<!-- Connect With Us -->

<section class="connect_with_us">

    <div class="container">

        <h2>Connect with us</h2>

        <ul class="contact_with_socail">

            <li>
                <a href="#">
                    <i class="fa fa-google-plus"></i>
                </a>
            </li>

            <li>
                <a href="#">
                    <i class="fa fa-linkedin"></i>
                </a>
            </li>

            <li>
                <a href="#">
                    <i class="fa fa-instagram"></i>
                </a>
            </li>

            <li>
                <a href="#">
                    <i class="fa fa-twitter"></i>
                </a>
            </li>

            <li>
                <a href="#">
                    <i class="fa fa-youtube"></i>
                </a>
            </li>

        </ul>

    </div>

</section>


<!-- Footer Area -->

<footer class="footer_area">

    <div class="container">

        <div class="footer_inner row">

            <div class="col-lg-5 col-md-6 footer_logo">

                <a href="index.php">
                    <img src="images/logo.png" alt="">
                </a>

                <p>
                    Established in 2013 as the first cloud mining provider,
                    Blog has become a multi-functional Blog Categories,
                    trusted by over a million users.
                </p>

                <address>

                    <span>LOCATION</span>

                    <p>
                        12/4 New Yourk R Block Street 2101 USA
                    </p>

                </address>

            </div>


            <div class="col-lg-5 col-md-6">

                <div class="subscribe">

                    <h4>Subscribe</h4>

                    <p>
                        Sign up for our mailing list to get latest updates and offers
                    </p>

                    <div class="input-group">

                        <input
                            type="text"
                            class="form-control"
                            placeholder=""
                        >

                        <div class="input-group-append">

                            <span class="input-group-text">
                                <i class="fa fa-paper-plane"></i>
                            </span>

                        </div>

                    </div>

                    <h6>
                        Working Hours :
                        Monday-Saturday
                        <span>
                            Close : Sunday
                        </span>
                    </h6>

                </div>

            </div>


            <div class="col-lg-2 col-md-3 resources">

                <h4>Short Link</h4>

                <ul class="resources_list">

                    <li>
                        <a href="about.php">
                            About
                        </a>
                    </li>

                    <li>
                        <a href="contact.php">
                            Contact
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            Bug Bounty Program
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            Policy
                        </a>
                    </li>

                    <li>
                        <a href="faq.html">
                            FAQ
                        </a>
                    </li>

                    <li>
                        <a href="shop.php">
                            Shop
                        </a>
                    </li>

                </ul>

            </div>

        </div>

    </div>


    <div class="copy_right">

        <p>
            Copyright © 2018
            <a href="#">Mora</a>
            Developed by
            <a href="http://themazin.com">
                Themazin
            </a>
        </p>

    </div>

</footer>


<!-- Scroll Top Button -->

<button class="scroll-top">

    <i class="fa fa-angle-double-up"></i>

</button>


<!-- Preloader -->

<div class="preloader"></div>


<!-- jQuery -->

<script src="js/jquery-3.3.1.min.js"></script>

<script src="js/popper.min.js"></script>

<!-- Bootstrap -->

<script src="js/bootstrap.min.js"></script>

<!-- Extra Plugin -->

<script src="vendors/animate-css/wow.min.js"></script>

<!-- Theme JS -->

<script src="js/theme.js"></script>

<script>
function previewProfileAvatar(input) {
    if (input.files && input.files[0]) {
        const file = input.files[0];
        if (!file.type.match(/^image\//)) {
            alert("Please select a valid image file (JPG, PNG, WEBP, GIF).");
            input.value = "";
            return;
        }
        if (file.size > 5 * 1024 * 1024) {
            alert("File is too large. Maximum size is 5MB.");
            input.value = "";
            return;
        }
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.getElementById('avatar_preview');
            const placeholder = document.getElementById('avatar_placeholder');
            const btnText = document.getElementById('avatar_btn_text');
            const removeBtn = document.getElementById('avatar_remove_btn');
            const hintText = document.getElementById('avatar_hint_text');

            if (preview && placeholder) {
                preview.src = e.target.result;
                preview.style.display = 'block';
                placeholder.style.display = 'none';
            }
            if (btnText) btnText.textContent = "Change";
            if (removeBtn) removeBtn.style.display = "inline-flex";
            if (hintText) hintText.textContent = file.name + " (" + (file.size / 1024).toFixed(0) + " KB)";
        };
        reader.readAsDataURL(file);
    }
}

function removeProfileAvatar(e) {
    if (e) {
        e.preventDefault();
        e.stopPropagation();
    }
    const input = document.getElementById('profile_image_input');
    const preview = document.getElementById('avatar_preview');
    const placeholder = document.getElementById('avatar_placeholder');
    const btnText = document.getElementById('avatar_btn_text');
    const removeBtn = document.getElementById('avatar_remove_btn');
    const hintText = document.getElementById('avatar_hint_text');

    if (input) input.value = "";
    if (preview) {
        preview.src = "";
        preview.style.display = "none";
    }
    if (placeholder) placeholder.style.display = "flex";
    if (btnText) btnText.textContent = "Choose Photo";
    if (removeBtn) removeBtn.style.display = "none";
    if (hintText) hintText.innerHTML = "Profile Picture (Optional &bull; Max 5MB)";
}
</script>

</body>

</html>